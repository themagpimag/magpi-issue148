#define SOUND_GPIO 3

void setupSound();
void playTone(int frequency, unsigned long duration);

