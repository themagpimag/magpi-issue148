extern const char * version;

unsigned long ulongDiff(unsigned long end, unsigned long start);

